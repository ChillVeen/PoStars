//
//  StarrrApp.swift
//  Starrr
//
//  Created by Praveen Singh on 27/02/25.
//

import SwiftUI

@main
struct StarrrApp: App {
    var body: some Scene {
        WindowGroup {
            //ContentView()
            CreativeCoding(creativeCoding: ContentView())
        }
    }
}
